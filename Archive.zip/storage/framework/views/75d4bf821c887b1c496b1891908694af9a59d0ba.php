<?php $__env->startSection('content'); ?>

<div class="s-form">
    <div class="d-flex align-items-center justify-content-between">
        <div class="d-flex align-items-center">
            <img class="img-jamu" class="mr-1" src="/img/jamu.png" alt="">
            <img class="img-halal" src="/img/halal.png" alt="">
        </div>
        <img class="img-badak" src="/img/badak.png" alt="">
    </div>
    <img class="main-logo w-100" src="/img/main-logo.png" alt="">
    

    <form action="<?php echo e(route('survey.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php $__currentLoopData = $questions['questions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="form-group rounded-box">
                <label class="label" for="gender"><?php echo e($question->question_text); ?></label>
               
                    
                    <?php if($question->type == 'multiple_choice'): ?>
                        <?php if(count($question->answers) > 0): ?>
                            <?php if($question->follow_text == ""): ?>
                                <div class="d-flex flex-column">
                            <?php else: ?>
                                <div class="d-flex align-items-center justify-content-between">
                                <span class="field mr-1"><?php echo e($question->follow_text); ?></span>
                            <?php endif; ?>
                                <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="custom-radio">
                                        <input id="male" type="radio" name="<?php echo e('question'.$question->id); ?>" value="<?php echo e($answer->id); ?>" <?php echo e(old('question' . $question->id) == $answer->id ? 'checked' : ''); ?>>
                                        <span class="radio-checkmark"></span>
                                        <?php echo e($answer->answer_text); ?>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if($question->follow_text_end != ""): ?>
                                    <span class="field mr-1"><?php echo e($question->follow_text_end); ?></span>
                                <?php endif; ?>
                            </div>

                        <?php endif; ?>
                    <?php else: ?>
                    <input type="text" name="<?php echo e('question'.$question->id); ?>" value="<?php echo e(old('question' . $question->id)); ?>" placeholder="Jawaban Anda" >
                    <?php endif; ?>
                   
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            Silahkan berikan jawaban untuk semua pertanyaan.
                        </div>
                    <?php endif; ?>

        <div class="d-flex align-items-center justify-content-between bottom-survey" style="padding: 50px 0 100px">
            <span class="field text-primary-dark">Kosongkan Formulir</span>
            <button type="submit" class="btn btn-light-green">Submit</button>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/guntur/cashtree/ELM/badak/lpcbevent/resources/views/survey.blade.php ENDPATH**/ ?>