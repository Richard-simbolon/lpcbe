<?php $__env->startSection('content'); ?>

<div class="form-page">
    <img class="left-img" src="/img/left-form.png" alt="">
    <img class="right-img" src="/img/right-form.png" alt="">
    <div class="d-flex align-items-center justify-content-between">
        <div class="d-flex align-items-center">
            <img class="img-jamu" class="mr-1" src="/img/jamu.png" alt="">
            <img class="img-halal" src="/img/halal.png" alt="">
        </div>
        <img class="img-badak" src="/img/badak.png" alt="">
    </div>
    <img class="main-logo w-100" src="/img/main-logo.png" alt="">
    <div class="form-fill">
        <img class="img-absolute" src="/img/product-2.png" alt="">
        <div class="form form-group rounded-box">
            <span class="disclaimer">
                Jika ingin mendapatkan produk
                <br>
                <b>Larutan Penyegar Cap Badak Legacy</b>
                <br>
                mohon isi data di bawah
            </span>
            <form action="<?php echo e(route('leads.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                    <div class="mb-2 mb-md-4">
                        <label class="label sm" for="name">Nama</label>
                        <input type="text" id="name" name="name" placeholder="Ketik Nama Anda" value="<?php echo e(old('name')); ?>">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-2 mb-md-4">
                        <label class="label sm" for="email">Email</label>
                        <input type="email" id="email" name="email" placeholder="Ketik Email Anda" value="<?php echo e(old('email')); ?>">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-2 mb-md-4">
                        <label class="label sm" for="phone">Nomor Handphone</label>
                        <input type="text" id="phone" name="phone" placeholder="Ketik No Telepon Anda" value="<?php echo e(old('phone')); ?>">
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-2 mb-md-4">
                        <label class="label sm" for="address">Alamat</label>
                        <textarea id="address" name="address" placeholder="Ketik Alamat Anda" class="form-control" rows="5"><?php echo e(old('address')); ?></textarea>
                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
            
                    <div class="mb-2 mb-md-4">
                        <label class="label sm" for="account">Akun Instagram</label>
                        <input type="text" id="account" name="username_id" placeholder="Ketik ID Instagram" class="form-control" value="<?php echo e(old('username_id')); ?>">
                        <?php $__errorArgs = ['username_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <button class="btn btn-light-green">KIRIM</button>
            </form>
        </div>
    </div>
    <div class="copyright">© 2024 LARUTAN PENYEGAR CAP BADAK. ALL RIGHTS RESERVED.</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/guntur/cashtree/ELM/badak/lpcbevent/resources/views/form.blade.php ENDPATH**/ ?>